<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SmsTemplateController extends Controller
{
    //
}
