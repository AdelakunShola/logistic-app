<?php

namespace App\Http\Controllers;



class RouteController extends Controller
{
    //
}